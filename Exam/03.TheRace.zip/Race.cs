﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace TheRace
{
    public class Race
    {
        private List<Racer> data;

        public string Name { get; set; }

        public int Capacity { get; set; }

        public int Count { get { return data.Count; } }

        public Race(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            data = new List<Racer>();
        }

        public void Add(Racer Racer)
        {
            if (Capacity > data.Count)
                data.Add(Racer);
        }
        public bool Remove(string name)
        {
            Racer nameCar = data.FirstOrDefault(n => n.Name == name);

            if (data.Contains(nameCar))
            {
                data.Remove(nameCar);
                return true;
            }
            else
                return false;
        }

        public Racer GetOldestRacer()
        {
            Racer ageRacer = data.OrderByDescending(x => x.Age).FirstOrDefault();
            return ageRacer;
        }

        public Racer GetRacer(string name)
        {
            Racer nameRacer = data.FirstOrDefault(n => n.Name == name);
            return nameRacer;
        }

        public Racer GetFastestRacer()
        {
            Racer hightSpeed = data.OrderByDescending(x => x.Car.Speed).FirstOrDefault();
            return hightSpeed;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Racers participating at {this.Name}:");

            foreach (var racaser in data)
            {
                sb.AppendLine(racaser.ToString());
            }

            return sb.ToString().TrimEnd();
        }
    }
}
