﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<double> list = new List<double>();

            for (int i = 0; i < n; i++)
            {
                double number = double.Parse(Console.ReadLine());
                list.Add(number);
            }

            double compare = double.Parse(Console.ReadLine());
            Console.WriteLine(Box<double>.Return(compare, list));
        }
    }
}
