﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace GenericBoxOfString
{
    public class Box<T>
        where T : IComparable<T>
    {
        public static int Return(T element, List<T> list)
        {
            return list.Where(x => x.CompareTo(element) > 0).Count();
        }
    }
}
