﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                Engine engine = null;

                string model = command[0];
                int power = int.Parse(command[1]);

                if (command.Length == 4)
                {
                    int displacement = int.Parse(command[2]);
                    string efficiency = command[3];

                    engine = new Engine(model, power, displacement, efficiency);
                }
                else if (command.Length == 3)
                {
                    int displacement;
                    bool isDisplacement = int.TryParse(command[2], out displacement);

                    if (isDisplacement)
                    {
                        engine = new Engine(model, power, displacement);
                    }
                    else
                    {
                        engine = new Engine(model, power, command[2]);
                    }
                }
                else if (command.Length == 2)
                {
                    engine = new Engine(model, power);
                }

                if (engine != null)
                {
                    engines.Add(engine);
                }
            }

            int m = int.Parse(Console.ReadLine());

            for (int i = 0; i < m; i++)
            {
                string[] carArg = Console.ReadLine()
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                    .ToArray();

                Car car = null;
                string model = carArg[0];
                Engine engine = engines.First(e => e.Model == carArg[1]);

                if (carArg.Length == 2)
                {
                    car = new Car(model, engine);
                }
                else if (carArg.Length == 3)
                {
                    int weight;
                    bool isWeight = int.TryParse(carArg[2], out weight);

                    if (isWeight)
                    {
                        car = new Car(model, engine, weight);
                    }
                    else
                    {
                        car = new Car(model, engine, carArg[2]);
                    }
                }
                else if (carArg.Length == 4)
                {
                    int weight = int.Parse(carArg[2]);
                    string color = carArg[3];

                   car = new Car(model, engine, weight, color);
                }

                if (car != null)
                {
                    cars.Add(car);
                }
            }

            foreach (var car in cars)
            {
                Console.WriteLine(car);
            }
        }
    }
}
